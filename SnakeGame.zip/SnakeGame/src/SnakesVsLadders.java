
import java.util.Random;
import java.util.Scanner;

public class SnakesVsLadders {
	
	int[] board = new int[100];	//making board 
	
	static int[] snakeHead =  new int[] {17, 48, 50, 62, 65, 76, 89, 93, 95, 99};
	
	static int[] snakeTail = {6, 11, 19, 23, 53, 60, 68, 75, 80, 88};
	
	static int[] ladderTop = {38, 14, 31, 26, 42, 44, 67, 84, 98, 91, 94};
	
	static int[] ladderBottom = {2, 7, 8, 15, 21, 28, 36, 51, 71, 78, 87};
	
	static int[] players, playerTrapped;
	
	static Random rand = new Random();
	
	static int dice, turn, n, won;//turn represents the index of our array Players
	
	static boolean six = false;	
	
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the number of Players Max are 4 Min are 2 \n");
		n = input.nextInt();
		if(n >= 2 && n <= 4){
			playerTrapped = new int[n];
			players = new int[n];
			startTheGame();
		}
		input.close();
	}
	
	//this method compares the player position with board and add dice number to player's position at each iteration
	public static void addingDiceNumber(){
		
		dice = rollTheDice();
		
		System.out.println("Player: "+turn+" Previous Points: "+players[turn]);
		
		if(players[turn]+dice <= 100){

			if(dice != 6 && playerTrapped[turn] == 0){	//if dice is less than 6 and player is not trapped
		
				players[turn] = players[turn]+dice;		//adding dice value to players position
				snakes(snakeHead, snakeTail, turn);	//checking snakes mouth condition
				ladders(ladderTop, ladderBottom, turn);	//checking ladder top
				
			}else{
				
				players[turn] = players[turn]+dice;
				six = true;
				playerTrapped[turn] = 0;				//untrapping player 
				snakes(snakeHead, snakeTail, turn);	//checking snakes condition
				ladders(ladderTop, ladderBottom, turn);	//checking ladder condition
			
			}
		}
		
	} 
	
	public static void startTheGame(){
		int iteration = 0;
		turn = 0;
		won = -1;
		while(won == -1){
			
			System.out.println("\nIteration No:"+iteration+"\n");
			
			addingDiceNumber();
			
			System.out.println("NewPoints: "+players[turn]);		// index is 0 or 1
			
			if(players[turn] == 100){
				won = turn;
				System.out.println("\nPlayer "+turn+" won!");
			}
			
			if(!six){			//if not six turn passes to next player
				iteration++;
				turn++;
			}else{
				six = false;
			}

			if(turn == n){			
				turn = 0;
			}
		}
	}

	//this method returns 1 to 6 for dice values
	public static int rollTheDice() {
		int number = rand.nextInt(6) + 1;
		System.out.println("Dice number: "+number);
		return number; 
	}
	
	
	private static boolean sampComparison(int[] snakeTop, int turn){
		
		boolean contains  = false;
		for ( int i=0;i<snakeHead.length;i++){
			if ( players[turn] == snakeHead[i]){
				contains = true;
			}
		}
		if (contains){
			return true;
		}else{
			return false;
		}
	}
	

	private static void snakes(int[] snakeHead, int[] snakeTail, int turn){
		int indexsnakeHead = 0;
		if( sampComparison(snakeHead,turn) ){
			
			int element = players[turn];		//string players position into element
			
			System.out.println("element: " + element);
			
			for(int i=0; i<snakeHead.length; i++){
				if(snakeHead[i] == element){	// if position is equal to some snake number
					indexsnakeHead = i;
				}
			}
			
			System.out.println("indexsnakeHead: " + indexsnakeHead);
			
			System.out.println(" Snake at: " + players[turn]);
			
			players[turn] = snakeTail[indexsnakeHead];
			
			System.out.println("Down to: " + players[turn]);
			
			playerTrapped[turn] = 1;		//player trapped
		}
	}
	
	
	private static boolean ladderComparison(int[] ladderTail, int turn){
	
		boolean contains  = false;
		for ( int i=0;i<ladderTail.length;i++){
			if ( players[turn] == ladderTail[i]){
				contains = true;
			}
		}
		if (contains){
			return true;
		}else{
			return false;
		}

	}
	
	//This method checks any ladders starting postion with that of players position and than update players position accordingly
	private static void ladders(int[] ladderTop, int[] ladderBottom, int turn){

		int indexLadderBottom = 0;
		
		if( ladderComparison(ladderBottom,turn) ){
			int element = players[turn];
			System.out.println("element: " + element);
			
			for(int i=0; i<ladderBottom.length; i++){
				if(ladderBottom[i] == element){			//getting ladder bottom position
					indexLadderBottom = i;
				}
			}
			
			//System.out.println("indexLadderBottom: " + indexLadderBottom);
			
			System.out.println("LadderBottom at: " + players[turn]);
			
			players[turn] = ladderTop[indexLadderBottom];
			
			System.out.println("Up to: " + players[turn]);
			
			six = true;
		}
	}
	
}
