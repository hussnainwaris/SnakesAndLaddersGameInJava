import static org.junit.Assert.*;

import org.junit.Test;

public class SnakesAndLaddersTest {

	@Test
	public void testDice(){
		int []dice = {1,2,3,4,5,6};
		int get_D = SnakesVsLadders.rollTheDice();
		boolean check = false;
		for ( int i = 0; i<6;i++){

			if(get_D == dice[i]){
				check = true;
				break;
			}
		}
		if (check ){
			assertTrue(true);
		}
		if(!check){
			assertFalse(true);
		}
	}
}
